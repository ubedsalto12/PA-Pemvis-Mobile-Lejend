﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class DataPemesanan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.btnexit = New System.Windows.Forms.Button()
        Me.btnpesan = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.total = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.pembayaran = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.jml = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.harga = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.telepon = New System.Windows.Forms.Label()
        Me.id = New System.Windows.Forms.Label()
        Me.nama = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txttotal = New System.Windows.Forms.TextBox()
        Me.cbpembayaran = New System.Windows.Forms.ComboBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtharga = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.cbkodediamond = New System.Windows.Forms.ComboBox()
        Me.txtdiamond = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtkode = New System.Windows.Forms.TextBox()
        Me.txtjumlah = New System.Windows.Forms.TextBox()
        Me.txtid = New System.Windows.Forms.TextBox()
        Me.txtnama = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnedit = New System.Windows.Forms.Button()
        Me.btndelete = New System.Windows.Forms.Button()
        Me.txtcari = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.btntambah = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnclear
        '
        Me.btnclear.BackColor = System.Drawing.Color.Transparent
        Me.btnclear.Font = New System.Drawing.Font("Sitka Banner", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclear.Location = New System.Drawing.Point(196, 372)
        Me.btnclear.Margin = New System.Windows.Forms.Padding(2)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(50, 28)
        Me.btnclear.TabIndex = 13
        Me.btnclear.Text = "Clear"
        Me.btnclear.UseVisualStyleBackColor = False
        '
        'btnexit
        '
        Me.btnexit.BackColor = System.Drawing.Color.Transparent
        Me.btnexit.Font = New System.Drawing.Font("Sitka Banner", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit.Location = New System.Drawing.Point(388, 372)
        Me.btnexit.Margin = New System.Windows.Forms.Padding(2)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(50, 28)
        Me.btnexit.TabIndex = 11
        Me.btnexit.Text = "Exit"
        Me.btnexit.UseVisualStyleBackColor = False
        '
        'btnpesan
        '
        Me.btnpesan.BackColor = System.Drawing.Color.Transparent
        Me.btnpesan.Font = New System.Drawing.Font("Sitka Banner", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpesan.Location = New System.Drawing.Point(736, 722)
        Me.btnpesan.Margin = New System.Windows.Forms.Padding(2)
        Me.btnpesan.Name = "btnpesan"
        Me.btnpesan.Size = New System.Drawing.Size(61, 28)
        Me.btnpesan.TabIndex = 10
        Me.btnpesan.Text = "Tambah"
        Me.btnpesan.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.total)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.pembayaran)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.Label26)
        Me.GroupBox2.Controls.Add(Me.jml)
        Me.GroupBox2.Controls.Add(Me.Label22)
        Me.GroupBox2.Controls.Add(Me.harga)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.telepon)
        Me.GroupBox2.Controls.Add(Me.id)
        Me.GroupBox2.Controls.Add(Me.nama)
        Me.GroupBox2.Font = New System.Drawing.Font("Sitka Banner", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.GroupBox2.Location = New System.Drawing.Point(466, 274)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(374, 198)
        Me.GroupBox2.TabIndex = 8
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "[ DETAIL PEMESANAN ]"
        '
        'total
        '
        Me.total.AutoSize = True
        Me.total.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.total.Location = New System.Drawing.Point(272, 111)
        Me.total.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.total.Name = "total"
        Me.total.Size = New System.Drawing.Size(14, 20)
        Me.total.TabIndex = 42
        Me.total.Text = "-"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label15.Location = New System.Drawing.Point(232, 111)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(45, 20)
        Me.Label15.TabIndex = 41
        Me.Label15.Text = "Total  :"
        '
        'pembayaran
        '
        Me.pembayaran.AutoSize = True
        Me.pembayaran.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.pembayaran.Location = New System.Drawing.Point(77, 165)
        Me.pembayaran.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.pembayaran.Name = "pembayaran"
        Me.pembayaran.Size = New System.Drawing.Size(14, 20)
        Me.pembayaran.TabIndex = 24
        Me.pembayaran.Text = "-"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label18.Location = New System.Drawing.Point(2, 165)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(86, 20)
        Me.Label18.TabIndex = 23
        Me.Label18.Text = "Pembayaran  :"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label26.Location = New System.Drawing.Point(85, 31)
        Me.Label26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(15, 20)
        Me.Label26.TabIndex = 18
        Me.Label26.Text = "/"
        '
        'jml
        '
        Me.jml.AutoSize = True
        Me.jml.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.jml.Location = New System.Drawing.Point(77, 149)
        Me.jml.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.jml.Name = "jml"
        Me.jml.Size = New System.Drawing.Size(14, 20)
        Me.jml.TabIndex = 15
        Me.jml.Text = "-"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label22.Location = New System.Drawing.Point(29, 149)
        Me.Label22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(69, 20)
        Me.Label22.TabIndex = 14
        Me.Label22.Text = "Jumlah  :    "
        '
        'harga
        '
        Me.harga.AutoSize = True
        Me.harga.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.harga.Location = New System.Drawing.Point(77, 130)
        Me.harga.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.harga.Name = "harga"
        Me.harga.Size = New System.Drawing.Size(14, 20)
        Me.harga.TabIndex = 11
        Me.harga.Text = "-"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label14.Location = New System.Drawing.Point(5, 130)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(51, 20)
        Me.Label14.TabIndex = 6
        Me.Label14.Text = "Harga  :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label13.Location = New System.Drawing.Point(2, 111)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(12, 20)
        Me.Label13.TabIndex = 5
        Me.Label13.Text = " "
        '
        'telepon
        '
        Me.telepon.AutoSize = True
        Me.telepon.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.telepon.Location = New System.Drawing.Point(96, 31)
        Me.telepon.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.telepon.Name = "telepon"
        Me.telepon.Size = New System.Drawing.Size(14, 20)
        Me.telepon.TabIndex = 2
        Me.telepon.Text = "-"
        '
        'id
        '
        Me.id.AutoSize = True
        Me.id.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.id.Location = New System.Drawing.Point(31, 52)
        Me.id.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.id.Name = "id"
        Me.id.Size = New System.Drawing.Size(14, 20)
        Me.id.TabIndex = 1
        Me.id.Text = "-"
        '
        'nama
        '
        Me.nama.AutoSize = True
        Me.nama.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.nama.Location = New System.Drawing.Point(31, 31)
        Me.nama.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.nama.Name = "nama"
        Me.nama.Size = New System.Drawing.Size(14, 20)
        Me.nama.TabIndex = 0
        Me.nama.Text = "-"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txttotal)
        Me.GroupBox1.Controls.Add(Me.cbpembayaran)
        Me.GroupBox1.Controls.Add(Me.btnpesan)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.txtharga)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.cbkodediamond)
        Me.GroupBox1.Controls.Add(Me.txtdiamond)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.txtkode)
        Me.GroupBox1.Controls.Add(Me.txtjumlah)
        Me.GroupBox1.Controls.Add(Me.txtid)
        Me.GroupBox1.Controls.Add(Me.txtnama)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Sitka Banner", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(10, 42)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(832, 228)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label8.Location = New System.Drawing.Point(381, 190)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(35, 20)
        Me.Label8.TabIndex = 40
        Me.Label8.Text = "Total"
        '
        'txttotal
        '
        Me.txttotal.Location = New System.Drawing.Point(420, 188)
        Me.txttotal.Margin = New System.Windows.Forms.Padding(2)
        Me.txttotal.Name = "txttotal"
        Me.txttotal.ReadOnly = True
        Me.txttotal.Size = New System.Drawing.Size(107, 25)
        Me.txttotal.TabIndex = 39
        '
        'cbpembayaran
        '
        Me.cbpembayaran.FormattingEnabled = True
        Me.cbpembayaran.Items.AddRange(New Object() {"Cash", "Debit"})
        Me.cbpembayaran.Location = New System.Drawing.Point(421, 104)
        Me.cbpembayaran.Name = "cbpembayaran"
        Me.cbpembayaran.Size = New System.Drawing.Size(106, 28)
        Me.cbpembayaran.TabIndex = 32
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label19.Location = New System.Drawing.Point(340, 112)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(76, 20)
        Me.Label19.TabIndex = 31
        Me.Label19.Text = "Pembayaran"
        '
        'txtharga
        '
        Me.txtharga.Location = New System.Drawing.Point(420, 74)
        Me.txtharga.Margin = New System.Windows.Forms.Padding(2)
        Me.txtharga.Name = "txtharga"
        Me.txtharga.ReadOnly = True
        Me.txtharga.Size = New System.Drawing.Size(107, 25)
        Me.txtharga.TabIndex = 27
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label17.Location = New System.Drawing.Point(375, 77)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(41, 20)
        Me.Label17.TabIndex = 26
        Me.Label17.Text = "Harga"
        '
        'cbkodediamond
        '
        Me.cbkodediamond.FormattingEnabled = True
        Me.cbkodediamond.Items.AddRange(New Object() {"1", "2", "3", "4", "5"})
        Me.cbkodediamond.Location = New System.Drawing.Point(420, 12)
        Me.cbkodediamond.Name = "cbkodediamond"
        Me.cbkodediamond.Size = New System.Drawing.Size(75, 28)
        Me.cbkodediamond.TabIndex = 24
        '
        'txtdiamond
        '
        Me.txtdiamond.Location = New System.Drawing.Point(500, 12)
        Me.txtdiamond.Margin = New System.Windows.Forms.Padding(2)
        Me.txtdiamond.Name = "txtdiamond"
        Me.txtdiamond.ReadOnly = True
        Me.txtdiamond.Size = New System.Drawing.Size(328, 25)
        Me.txtdiamond.TabIndex = 22
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label11.Location = New System.Drawing.Point(6, 24)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(95, 20)
        Me.Label11.TabIndex = 17
        Me.Label11.Text = "Kode Pembelian"
        '
        'txtkode
        '
        Me.txtkode.Location = New System.Drawing.Point(122, 15)
        Me.txtkode.Margin = New System.Windows.Forms.Padding(2)
        Me.txtkode.Name = "txtkode"
        Me.txtkode.Size = New System.Drawing.Size(102, 25)
        Me.txtkode.TabIndex = 16
        '
        'txtjumlah
        '
        Me.txtjumlah.Location = New System.Drawing.Point(421, 45)
        Me.txtjumlah.Margin = New System.Windows.Forms.Padding(2)
        Me.txtjumlah.Name = "txtjumlah"
        Me.txtjumlah.Size = New System.Drawing.Size(108, 25)
        Me.txtjumlah.TabIndex = 9
        '
        'txtid
        '
        Me.txtid.Location = New System.Drawing.Point(122, 86)
        Me.txtid.Margin = New System.Windows.Forms.Padding(2)
        Me.txtid.Name = "txtid"
        Me.txtid.Size = New System.Drawing.Size(202, 25)
        Me.txtid.TabIndex = 8
        '
        'txtnama
        '
        Me.txtnama.Location = New System.Drawing.Point(122, 47)
        Me.txtnama.Margin = New System.Windows.Forms.Padding(2)
        Me.txtnama.Name = "txtnama"
        Me.txtnama.Size = New System.Drawing.Size(202, 25)
        Me.txtnama.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(323, 45)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(99, 20)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Jumlah Diamond"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(326, 15)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(90, 20)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Paket Diamond"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(5, 88)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(97, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Id Mobile legend"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(7, 52)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nama Pemesan"
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(8, 474)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.Size = New System.Drawing.Size(833, 251)
        Me.DataGridView1.TabIndex = 14
        '
        'btnedit
        '
        Me.btnedit.BackColor = System.Drawing.Color.Transparent
        Me.btnedit.Font = New System.Drawing.Font("Sitka Banner", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnedit.Location = New System.Drawing.Point(260, 372)
        Me.btnedit.Margin = New System.Windows.Forms.Padding(2)
        Me.btnedit.Name = "btnedit"
        Me.btnedit.Size = New System.Drawing.Size(50, 28)
        Me.btnedit.TabIndex = 15
        Me.btnedit.Text = "Edit"
        Me.btnedit.UseVisualStyleBackColor = False
        '
        'btndelete
        '
        Me.btndelete.BackColor = System.Drawing.Color.Transparent
        Me.btndelete.Font = New System.Drawing.Font("Sitka Banner", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndelete.Location = New System.Drawing.Point(320, 372)
        Me.btndelete.Margin = New System.Windows.Forms.Padding(2)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(59, 28)
        Me.btndelete.TabIndex = 16
        Me.btndelete.Text = "Hapus"
        Me.btndelete.UseVisualStyleBackColor = False
        '
        'txtcari
        '
        Me.txtcari.Location = New System.Drawing.Point(130, 422)
        Me.txtcari.Margin = New System.Windows.Forms.Padding(2)
        Me.txtcari.Multiline = True
        Me.txtcari.Name = "txtcari"
        Me.txtcari.Size = New System.Drawing.Size(324, 25)
        Me.txtcari.TabIndex = 28
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Trebuchet MS", 28.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label9.Location = New System.Drawing.Point(118, 2)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(653, 49)
        Me.Label9.TabIndex = 28
        Me.Label9.Text = "DATA DIAMOND MOBEL LEJND ANDRI"
        '
        'btntambah
        '
        Me.btntambah.Font = New System.Drawing.Font("Sitka Banner", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btntambah.Location = New System.Drawing.Point(127, 372)
        Me.btntambah.Margin = New System.Windows.Forms.Padding(2)
        Me.btntambah.Name = "btntambah"
        Me.btntambah.Size = New System.Drawing.Size(61, 28)
        Me.btntambah.TabIndex = 32
        Me.btntambah.Text = "Pesan"
        Me.btntambah.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label16.Location = New System.Drawing.Point(284, 405)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(32, 13)
        Me.Label16.TabIndex = 41
        Me.Label16.Text = "CARI"
        '
        'DataPemesanan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Posttest5.My.Resources.Resources.back2
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(852, 736)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.btntambah)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.btnexit)
        Me.Controls.Add(Me.btndelete)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.btnedit)
        Me.Controls.Add(Me.txtcari)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnclear)
        Me.Name = "DataPemesanan"
        Me.Text = "DataPemesanan"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnclear As Button
    Friend WithEvents btnpesan As Button
    Friend WithEvents btnexit As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label26 As Label
    Friend WithEvents jml As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents harga As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents telepon As Label
    Friend WithEvents id As Label
    Friend WithEvents nama As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtharga As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents cbkodediamond As ComboBox
    Friend WithEvents txtdiamond As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents txtkode As TextBox
    Friend WithEvents txtjumlah As TextBox
    Friend WithEvents txtid As TextBox
    Friend WithEvents txtnama As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnedit As Button
    Friend WithEvents btndelete As Button
    Friend WithEvents txtcari As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents cbpembayaran As ComboBox
    Friend WithEvents Label19 As Label
    Friend WithEvents pembayaran As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txttotal As TextBox
    Friend WithEvents total As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents btntambah As Button
    Friend WithEvents Label16 As Label
End Class
